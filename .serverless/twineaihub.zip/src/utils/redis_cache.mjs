import redis from 'redis';
import mongoose from 'mongoose';
import express from 'express';

const app = express();


// middleware to check cache


